---
name: agent-selection
description: Systematic framework for selecting the optimal specialized agent for any task. Use when delegating to subagents via the Task tool to ensure the most appropriate specialist is chosen based on framework, domain, task type, and complexity. Applies decision tree logic to match tasks with agent expertise.
---

# Agent Selection

## Overview

Select the optimal specialized agent for any task using systematic decision-making criteria. This skill provides a structured approach to matching tasks with agent expertise across frameworks, domains, project types, and quality concerns.

## When to Use This Skill

Invoke this skill before using the Task tool to delegate work to a specialized agent. Specifically use when:

- Delegating complex or multi-step tasks that match specialized agent capabilities
- Framework-specific work (React, Vue, Laravel, Node.js, Swift, etc.)
- Domain-specific tasks (database optimization, security audits, API design, graphics)
- Quality assurance tasks (code review, testing strategy, architecture review, performance profiling)
- Project-type specific work (MCP servers, Figma plugins, VS Code extensions, game development)
- Multi-domain tasks requiring orchestration across multiple specialists
- Exploring unfamiliar codebases or investigating complex bugs

## Agent Selection Process

Follow this systematic process to select the appropriate agent:

### Step 1: Analyze Task Characteristics

Identify the key characteristics of the task:

1. **Framework dependency**: Does the task require specific framework knowledge?
   - Frontend: React, Vue, SwiftUI, Preact, C++/JUCE
   - Backend: Laravel, Node.js, Vapor/Swift, PHP
   - UI/Styling: Blade, SASS/SCSS

2. **Domain specialization**: Does the task fall into a specific domain?
   - Database work (SQL optimization, migrations, indexing)
   - Security (audits, vulnerability assessment, OWASP compliance)
   - API design (REST/GraphQL, versioning, contracts)
   - Graphics (OpenGL, shaders, rendering)
   - Game development (Unity 2D/3D)
   - Documentation (API docs, guides, technical writing)

3. **Project type**: Is this a specific project type?
   - MCP server development
   - Figma plugin creation
   - VS Code extension development
   - CMS UI polish and animations

4. **Quality concern**: Is this a quality/architecture task?
   - Code review (after writing/modifying code)
   - Testing strategy and implementation
   - Architecture enforcement and refactoring
   - Performance optimization

5. **Investigation type**: Is this exploratory or diagnostic?
   - Codebase exploration (finding files/patterns)
   - Bug investigation (root cause analysis)
   - Planning complex implementations

### Step 2: Apply Selection Logic

Use this decision tree to select the agent:

**Framework-Specific Tasks** → Select framework agent
- React work → `react-specialist`
- React Native mobile → `react-native-specialist`
- Vue 3 work → `vue-expert`
- SwiftUI apps → `swiftui-specialist`
- Size-constrained UIs → `preact-specialist`
- Audio plugins/DSP → `cpp-ui-specialist`
- Laravel backend → `laravel-specialist`
- Node.js backend → `nodejs-backend-specialist`
- Swift backend → `swift-backend-specialist`
- Pure PHP (non-Laravel) → `php-pro`
- Blade templates → `blade-specialist`
- Complex CSS/theming → `sass-expert`

**Domain-Specific Tasks** → Select domain specialist
- Database work → `database-specialist`
- Security audits → `security-auditor`
- API design → `api-designer`
- TypeScript strict typing → `typescript-guardian`
- Documentation → `technical-writer`
- OpenGL/shaders → `opengl-shader-specialist`
- Unity 3D games → `unity3d-specialist`
- Unity 2D games → `unity2d-specialist`

**Project-Type Tasks** → Select project specialist
- MCP servers → `mcp-server-specialist`
- Figma plugins → `figma-plugin-specialist`
- VS Code extensions → `vscode-extension-specialist`
- CMS UI polish → `ui-polish-specialist`
- CMS animations → `animation-specialist`

**Quality & Architecture Tasks** → Select quality agent
- Code review → `code-reviewer` (use proactively after coding)
- Test strategy → `testing-architect`
- Architecture review → `architecture-guardian`
- Performance issues → `performance-profiler`

**Investigation Tasks** → Select investigation agent
- Bug investigation → `debugger`
- Codebase exploration → `Explore` (with thoroughness: "quick", "medium", "very thorough")
- Complex planning → `Plan`

**Multi-Domain Tasks** → Use orchestration
- Cross-domain coordination → `integration-coordinator`

**No Clear Match** → Use general delegation
- Ambiguous tasks → `general-purpose` (Claude Code auto-selects specialist)

### Step 3: Verify Selection

Before delegating, verify the selection makes sense:

1. **Expertise match**: Does the agent's expertise align with task requirements?
2. **Scope appropriateness**: Is the task complex enough to warrant delegation?
3. **Context availability**: Can the task be completed independently by the agent?
4. **Parallel execution**: Can multiple agents work in parallel on independent subtasks?

### Step 4: Delegate with Clear Context

When using the Task tool:

```python
Task(
  subagent_type='selected-agent',
  prompt='Clear, detailed description of the task with requirements and expected outcomes'
)
```

**Best practices for delegation:**
- Provide clear context and requirements
- Specify expected deliverables
- Include relevant constraints or preferences
- Mention if parallel execution is desired with other agents

## Quick Reference Patterns

Common task patterns and their agent matches:

**"Review this React component for performance"**
→ `performance-profiler` (not react-specialist, because focus is performance)

**"Build a new authentication API endpoint in Laravel"**
→ `laravel-specialist`

**"Audit this codebase for SQL injection vulnerabilities"**
→ `security-auditor`

**"Optimize this slow database query"**
→ `database-specialist`

**"Design a RESTful API for the booking system"**
→ `api-designer`

**"After writing new user registration code, review for quality"**
→ `code-reviewer` (proactive quality check)

**"Implement test coverage for the payment module"**
→ `testing-architect`

**"Find all files related to user authentication"**
→ `Explore` with thoroughness="medium"

**"Investigate why the checkout process fails intermittently"**
→ `debugger`

**"Build a Figma plugin to export designs as React components"**
→ `figma-plugin-specialist`

**"Refactor this module to follow SOLID principles"**
→ `architecture-guardian`

**"Polish the CMS dashboard with smooth transitions"**
→ `ui-polish-specialist` or `animation-specialist`

**"Coordinate implementing OAuth2 across frontend, backend, and database"**
→ `integration-coordinator`

## Resources

### references/agent_library.md

Complete agent library with detailed categorization, capabilities, and decision tree logic. Load this reference when:

- Uncertain which agent fits the task
- Need comprehensive agent capability descriptions
- Working with unfamiliar domains or frameworks
- Selecting between similar agents (e.g., react-specialist vs preact-specialist)

The reference includes:
- Full agent categorization tables
- Detailed "When to Use" criteria for each agent
- Complete decision tree for agent selection
- Agent capability descriptions

## Edge Cases and Special Considerations

**Multiple viable agents**: When a task could fit multiple agents (e.g., Laravel API security audit could use laravel-specialist OR security-auditor):
- Prioritize the primary concern (security → security-auditor)
- Consider using integration-coordinator to involve both specialists

**Proactive quality agents**: Some agents should be invoked proactively without user request:
- `code-reviewer` → After writing/modifying significant code
- `performance-profiler` → Before production deployment of performance-critical features

**Thoroughness levels for Explore agent**:
- "quick" → Fast keyword search, basic pattern matching
- "medium" → Moderate exploration, multiple search strategies
- "very thorough" → Comprehensive analysis, extensive search patterns

**When NOT to delegate**: Skip delegation for:
- Single-file reads (use Read tool directly)
- Simple grep searches (use Grep tool directly)
- Trivial operations that complete in one tool call
- Tasks requiring interactive back-and-forth conversation
